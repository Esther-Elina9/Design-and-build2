from time import sleep

import requests
import numpy as np
import cv2

url = "http://192.168.8.1:8083/?action=snapshot"
SavePath = "D:\desk\Design and Build 2\yolov8\runs\detect\predict"


def download_img() -> object:
    """
    从路由器上下载图像
    :return: opencv格式的图像
    """
    response = requests.get(url)
    data = response.content
    img1 = np.frombuffer(data, np.uint8)
    img_cv = cv2.imdecode(img1, cv2.IMREAD_ANYCOLOR)
    return img_cv


i = 1
while True:
    image = download_img()
    cv2.imshow("frame", image)

    print(i)
    print(cv2.imwrite(f'{SavePath}\{i}.jpg', image))
    i = i+1

    sleep(0.25)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cv2.destroyAllWindows()
