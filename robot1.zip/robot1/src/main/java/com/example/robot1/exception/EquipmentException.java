package com.example.robot1.exception;

public class EquipmentException extends RuntimeException{
    public EquipmentException(String message) {
        super(message);
    }
}
