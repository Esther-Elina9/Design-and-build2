package com.example.project2.record.controller;

public class RecordController {
}
