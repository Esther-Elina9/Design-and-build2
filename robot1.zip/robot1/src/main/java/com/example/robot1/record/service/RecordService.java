package com.example.robot1.record.service;

public class RecordService {
}
